package com.example.app_restaurante

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
